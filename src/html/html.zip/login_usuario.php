<?php
include('conecta.php');
session_start();

if (!isset($_POST['email']) || !isset($_POST['senha'])) {
    echo "Requisição inválida";
    exit;
}

$email = $conn->real_escape_string($_POST["email"]);
$senha = $conn->real_escape_string($_POST["senha"]);

$sql = "SELECT * FROM usuario WHERE ds_email = '$email' AND ds_senha = '$senha'";
$result = $conn->query($sql);

if ($result && $result->num_rows === 1) {

    $usuario = $result->fetch_assoc();

    $_SESSION['nome']  = $usuario['nm_usuario'];
    $_SESSION['email'] = $usuario['ds_email'];

    echo "OK";
    exit;

} else {
    echo "Falha ao logar! Email ou senha incorretos";
    exit;
}